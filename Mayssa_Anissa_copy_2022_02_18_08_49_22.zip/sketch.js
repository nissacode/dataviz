budgetValues = [];

function preload() {
  table = loadTable("eurostat.csv", "csv", "header");
}

function setup() {
  createCanvas(2100, 1000);
  numberOfRows = table.getRowCount();
  numberOfColumns = table.getColumnCount();
  frameRate(30);
  background(0);
  stroke(127);
  createLoop({
    gif: { fileName: "noiseLoop1d.gif" },
    noiseRadius: 0.3,
  });
}

function draw() {
  background('#EFEAF1');
  colorMode(RGB, 100);
  fill("#FFF");
  text("Poucentage d'ecoute via les plateforme de musique streaming en Europe",500,80 );
  
  text("Source Eurostat",40,540);

  const distributionFrequency = 0.01;
  for (let x = 0; x < width; x++) {
    const y = 400 + (animLoop.noise1D(x * distributionFrequency) * height) / 2;
    ellipse(x, y, 5);
  }

  for (var i = 0; i < numberOfRows; i++) {
    //place years
    fill(255);
    text(table.getString(i, 0), i * 70 + 45, 450);
    bar(i * 70 + 40, 330, table.getNum(i, 1));
    //pull numbers
    budgetValues[i] = table.getString(i, 0);
  }
}

function bar(x, y, data) {
  //rectangle %
  couleur = color("#51F588");
  fill(couleur);
  couleur1 = color("#B83FCA");
  rect(x, y - data, 60, data); // violet
  fill(couleur1);
  rect(x, y, 60, data); // vert
}
